const express = require("express");
const pokemonDb = require("../modules/pokemon-db.js");
const bodyParser=require('body-parser')
// Setup an express Router
const router = express.Router();

var urlencodedParser=bodyParser.urlencoded({extended:false});


router.get('/',(req,res)=>{
  const data=pokemonDb.getAllPokemon()
  res.render('admin',{array:data})
})


router.get('/add',urlencodedParser,(req,res)=>{
  let errors=[];
  if(!req.query.id){
    errors.push({text: "please enter your ID"});
  }
  if(!req.query.name){
    errors.push({text:"please enter name"})
  }
  if(!req.query.types){
    errors.push({text: "please choose type"})
  }
  if(!req.query.imageUrl){
    errors.push({text: 'please choose avatar'})
  }
  if(errors.length>0){
    res.render('admin',{
      errors: errors,
      id: req.query.id,
      name: req.query.name,
      types: req.query.types,
      imageUrl: req.query.imageUrl
    })
  }
  else{
    const newPokemon={
      id: req.query.id,
      name:req.query.name,
      description: req.query.description,
      types: req.query.types,
      imageUrl: req.query.imageUrl
    }
    pokemonDb.addPokemon(newPokemon)
  }
})

module.exports = router;