// Importing required modules
const express = require("express");
const pokemonDb = require("../modules/pokemon-db.js");
const bodyParser=require('body-parser')
// Setup an express Router
const router = express.Router();

// TODO Add your route handlers here
var urlencodedParser=bodyParser.urlencoded({extended:false});

//Returns information about a random Pokemon.
router.get('/pokemon/random',(req,res)=>{
  const array=pokemonDb.getAllPokemon()
  const id= Math.floor(Math.random()*array.length) 
  res.render("info",array[id])
})

//Returns information about the Pokemon with the given id.
router.get('/pokemon',(req,res)=>{
  const data=pokemonDb.getPokemonById(req.query.id)
  res.render("info",data)
})

router.get('/pokemon/types',(req,res)=>{
  const data=pokemonDb.loadTypeData()
  res.render("type",{array:data})
})

//Returns an array of type effectiveness data.

// Export the router so we can access it from other JS files using require()
module.exports = router;